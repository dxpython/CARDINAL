from pathlib import Path
from xml.sax.saxutils import escape
import xml.etree.ElementTree as ET
import json,re,math
R=Path(__file__).resolve().parents[1]
(R/'source/svg').mkdir(exist_ok=True)
INK='http://www.inkscape.org/namespaces/inkscape';NS='http://www.w3.org/2000/svg'
D='#243D4B'; BLUE='#426F89'; TEAL='#528B87'; GOLD='#AE8C5C'; GRAY='#687E88'; LINE='#CBD9DF'; PALE='#EDF4F7'; MINT='#EEF5F2'; SAND='#F7F3ED'
class S:
 def __init__(self,w,h,title):
  self.n=0;self.w=w;self.h=h
  self.a=[f'<svg xmlns="{NS}" xmlns:inkscape="{INK}" width="180mm" height="{180*h/w}mm" viewBox="0 0 {w} {h}"><title>{escape(title)}</title><desc>Based on manuscript LaTeX and supplementary methods. Generated pictograms are traced to editable paths in Inkscape; all text and diagram elements are editable vectors.</desc><defs><marker id="arr" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto" markerUnits="userSpaceOnUse"><path d="M1 1L9 5L1 9" fill="none" stroke="{GRAY}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>']
  self.layer('Background');self.box(0,0,w,h,'white',0);self.end()
 def id(self,p='obj'):self.n+=1;return p+str(self.n)
 def layer(self,n):self.a.append(f'<g id="{self.id("layer")}" inkscape:groupmode="layer" inkscape:label="{escape(n)}">')
 def end(self):self.a.append('</g>')
 def box(self,x,y,w,h,fill=PALE,r=12,stroke='none',sw=1.5):self.a.append(f'<rect id="{self.id()}" x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def text(self,x,y,t,size=24,color=D,bold=False,anchor='start',raw=False,serif=False):
  if not raw:
   t=escape(t)
   mp=str.maketrans('₀₁₂₃₄₅₆₇₈₉ᵢₖ','0123456789ik')
   t=re.sub('[₀₁₂₃₄₅₆₇₈₉ᵢₖ]+',lambda m:sub(m[0].translate(mp)),t)
   mp=str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹⁽⁾ᵗ','0123456789()t')
   t=re.sub('[⁰¹²³⁴⁵⁶⁷⁸⁹⁽⁾ᵗ]+',lambda m:sup(m[0].translate(mp)),t)
  self.a.append(f'<text id="{self.id("text")}" x="{x}" y="{y}" font-family="{"Times New Roman" if serif else "Arial"}" font-size="{size}" font-weight="{"bold" if bold else "normal"}" text-anchor="{anchor}" fill="{color}">{t}</text>')
 def path(self,d,color=GRAY,sw=2,arrow=False,dash=False):self.a.append(f'<path id="{self.id("path")}" d="{d}" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'+(' marker-end="url(#arr)"' if arrow else '')+(' stroke-dasharray="6 6"' if dash else '')+'/>')
 def line(self,x,y,X,Y,**kw):self.path(f'M{x},{y}L{X},{Y}',**kw)
 def circle(self,x,y,r,fill=BLUE,stroke='none',sw=1.8):self.a.append(f'<circle id="{self.id()}" cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def asset(self,key,x,y,w,h,color=BLUE):
  rt=ET.parse(R/f'assets/{key}.svg').getroot();bx,by,bw,bh=map(float,rt.get('viewBox').split());z=min(w/bw,h/bh)
  tx=x+(w-bw*z)/2-bx*z;ty=y+(h-bh*z)/2-by*z
  self.a.append(f'<g id="{self.id("asset")}" inkscape:label="images2 / Inkscape trace: {key}" transform="translate({tx},{ty}) scale({z})">')
  for p in rt.findall('{'+NS+'}path'):self.a.append(f'<path id="{self.id("traced")}" d="{p.get("d")}" fill="{color}"/>')
  self.end()
 def title(self,letter,t,x=40,y=49):self.text(x,y,letter,24,BLUE,True);self.text(x+33,y,t,27,D,True)
 def save(self,name):(R/f'source/svg/{name}.svg').write_text('\n'.join(self.a+['</svg>']))
def sub(t):return '<tspan baseline-shift="sub" font-size="70%">'+t+'</tspan>'
def sup(t):return '<tspan baseline-shift="super" font-size="70%">'+t+'</tspan>'
def people(s,x,y,color=TEAL):
 for dx,dy in [(-37,8),(37,8),(0,-5)]:
  s.circle(x+dx,y+dy,12,'white',color,2.5)
  s.path(f'M{x+dx-20},{y+dy+48} V{y+dy+30} Q{x+dx-20},{y+dy+17} {x+dx},{y+dy+17} Q{x+dx+20},{y+dy+17} {x+dx+20},{y+dy+30} V{y+dy+48}',color,2.5)
def masks(s,x,y,z=1):
 for r in range(3):
  for c in range(5):s.box(x+c*25*z,y+r*40*z,18*z,23*z,'white' if c==[1,3,0][r] else BLUE,3,LINE,1)

# Scientific drawing primitives; they remain separate, editable SVG objects.
COLORS=[BLUE,TEAL,GOLD]
PRIOR=[(0,2),(1,2),(2,3),(3,4),(5,4),(0,6),(6,7),(8,7),(7,9),(4,9),(10,9),(11,9)]
def group(s,n):s.a.append(f'<g id="{s.id("group")}" inkscape:label="{escape(n)}">')
def poly(s,pts,fill,stroke='none',sw=1):
 s.a.append(f'<polygon id="{s.id()}" points="'+ ' '.join(f'{x},{y}' for x,y in pts)+f'" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def diamond(s,x,y,r=10,c=BLUE):poly(s,[(x,y-r),(x+r,y),(x,y+r),(x-r,y)],c)
def heading(s,x,y,letter,t,c=BLUE):
 s.circle(x+13,y-8,15,c);s.text(x+13,y-2,letter,19,'white',True,'middle');s.text(x+39,y,t,27,D,True)
def matrix(s,x,y,n=6,cell=16,entries=None,c=BLUE,weighted=False):
 group(s,'Adjacency matrix' if entries else 'Schematic feature matrix')
 if entries is None:entries={(i,j):1 for i in range(n) for j in range(n) if (i*7+j*3)%5<2}
 if not isinstance(entries,dict):entries={p:1 for p in entries}
 for i in range(n):
  for j in range(n):
   v=entries.get((i,j),0)
   fill='white' if not v else (['#BCD1DC','#88ACBE',c][(i+2*j)%3] if weighted else c)
   s.box(x+j*cell,y+i*cell,cell-2,cell-2,fill,1,LINE,.6)
 s.end()
def vector(s,x,y,n=9,vertical=False,c=TEAL):
 for i in range(n):s.box(x+(0 if vertical else i*18),y+(i*18 if vertical else 0),14,14,[c,'#91B4B1','#CADCD6'][i%3],2)
def layer_net(s,x,y,w=260,h=180,drop=(),labels=True):
 group(s,'Encoder architecture, schematic nodes')
 cols=[5,5,4];pts=[]
 for j,n in enumerate(cols):pts.append([(x+j*w/2,y+h/2+(k-(n-1)/2)*h/5) for k in range(n)])
 for j in range(2):
  for a,(X,Y) in enumerate(pts[j]):
   for b,(XX,YY) in enumerate(pts[j+1]):
    if (a+b)%2==0:s.line(X+8,Y,XX-8,YY,color='#CFDBE0',sw=1)
 for j,p in enumerate(pts):
  for k,(X,Y) in enumerate(p):
   dropped=(j,k) in drop
   s.circle(X,Y,8,'white' if dropped else [BLUE,BLUE,TEAL][j],LINE if dropped else 'white',1.7)
   if dropped:
    s.line(X-4,Y-4,X+4,Y+4,color=LINE,sw=1.5);s.line(X-4,Y+4,X+4,Y-4,color=LINE,sw=1.5)
 if labels:
  for j,t in enumerate(['64','64','32']):s.text(x+j*w/2,y+h+29,t,21,GRAY,False,'middle')
 s.end()
def clusters(s,x,y,w=390,h=155):
 group(s,'Prototype-aligned latent space: schematic')
 centers=[(x+55,y+90),(x+w/2,y+42),(x+w-52,y+99)]
 offsets=[(-26,-11),(-19,16),(-10,-30),(8,-19),(21,7),(13,28),(-32,27),(34,-21)]
 for k,(cx,cy) in enumerate(centers):
  for dx,dy in offsets:s.circle(cx+dx,cy+dy,4.5,COLORS[k])
  diamond(s,cx,cy,10,COLORS[k]);s.text(cx,cy+61,['c'+sub('normal'),'c'+sub('mild'),'c'+sub('severe')][k],21,COLORS[k],False,'middle',raw=True)
 s.end()
def ring(s,cx,cy,r,counts,colors,sw=17):
 angle=-90
 for n,c in zip(counts,colors):
  end=angle+360*n/sum(counts)
  a,b=map(math.radians,[angle+1,end-1]);X=cx+r*math.cos(a);Y=cy+r*math.sin(a);xx=cx+r*math.cos(b);yy=cy+r*math.sin(b)
  s.path(f'M{X},{Y} A{r},{r} 0 {1 if end-angle>180 else 0} 1 {xx},{yy}',c,sw)
  angle=end

def fig1():
 s=S(1540,1040,'Study cohort: screening, reference grading and allocation')
 s.layer('Screening flow')
 heading(s,35,49,'a','Record screening')
 s.asset('clinical_record',71,105,114,133)
 s.text(228,147,'Screened records',26,D,True);s.text(228,205,'160',54,BLUE,True)
 s.line(55,271,740,271,color=LINE)
 # Branches are placed between successive retained cohorts.
 stage=[(330,'Unique examinations',155),(470,'Complete measurements',137),(610,'Quality passed',126),(750,'Final cohort',118)]
 s.line(252,247,252,330,arrow=True)
 for i,(y,lab,n) in enumerate(stage):
  s.box(55,y,395,83,MINT if i==3 else PALE,8)
  s.text(78,y+35,lab,20.5,TEAL if i==3 else BLUE,True)
  s.text(426,y+59,str(n),40,TEAL if i==3 else D,True,'end')
  # Exact retained count is also encoded by bar length (denominator 160).
  s.box(78,y+55,210*n/160,8,TEAL if i==3 else '#8CABBD',4)
  if i<3:s.line(252,y+83,252,y+140,arrow=True)
 reasons=[(294,'Duplicates',5),(441,'Missing measurements',18),(581,'Quality failure',11),(721,'Missing reference labels',8)]
 for y,t,n in reasons:
  s.path(f'M252,{y} H496',arrow=True)
  s.text(517,y+5,t,18,GRAY);s.text(771,y+6,str(n),24,D,True,'end')
 s.text(55,909,'Excluded',23,GRAY);s.text(178,910,'42',31,D,True)
 s.text(55,956,'160 − 42 = 118',25,BLUE)
 s.end();s.layer('Reference index')
 s.line(794,84,794,986,color=LINE)
 heading(s,839,49,'b','Reference-index grading',TEAL)
 for x,lab,wgt,c in [(844,'E/e′',.45,BLUE),(1069,'LAVI',.35,TEAL),(1294,'TR velocity',.20,GOLD)]:
  s.text(x,117,lab,24,c,True)
  s.box(x,141,187,13,'#E7EDF0',5);s.box(x,141,187*wgt/.45,13,c,5)
  s.text(x,192,f'{wgt:.2f} × z',25,c)
 s.path('M937,211 V236 H1160 M1162,211 V263 M1387,211 V236 H1162',color=GRAY)
 s.line(1162,239,1162,269,arrow=True)
 s.box(846,279,634,65,'#F5F7F8',6)
 s.text(1163,321,'P'+sub('d')+' = 0.45z(E/e′) + 0.35z(LAVI) + 0.20z(TR)',25,raw=True,serif=True,anchor='middle')
 s.line(1163,357,1163,383,arrow=True)
 # Each point is one retained case, not a simulated biomarker measurement.
 for x,lab,n,c,f,cut in [(844,'Normal',37,BLUE,PALE,'P'+sub('d')+' &lt; −0.35'),(1069,'Mild',42,TEAL,MINT,'−0.35 ≤ P'+sub('d')+' &lt; 0.70'),(1294,'Severe',39,GOLD,SAND,'P'+sub('d')+' ≥ 0.70')]:
  s.box(x,403,188,285,f,9);s.text(x+94,440,lab,25,c,True,'middle')
  s.text(x+94,478,cut,18,c,False,'middle',raw=True)
  for k in range(n):s.circle(x+32+(k%7)*21,y:=514+(k//7)*21,5.2,c)
  s.text(x+94,669,str(n),39,c,True,'middle')
 s.text(1479,724,'One dot = one case',19,GRAY,False,'end')
 s.end();s.layer('Stratified split')
 s.text(844,797,'Stratified allocation',25,D,True)
 total=634;off=844
 for n,c in [(82,BLUE),(18,TEAL),(18,GOLD)]:
  wid=total*n/118;s.box(off,828,wid-3,40,c,3);off+=wid
 for x,lab,n,c in [(844,'Training',82,BLUE),(1080,'Validation',18,TEAL),(1295,'Locked test',18,GOLD)]:
  s.text(x,915,str(n),37,c,True);s.text(x,950,lab,23,GRAY)
 s.end();s.save('fig1_patient_flow')

def fig2():
 s=S(1640,1080,'CARDINAL architecture and joint learning')
 s.layer('Module boundaries')
 s.text(35,48,'CARDINAL',32,D,True);s.text(234,47,'Physiology-guided representations and uncertainty',25,GRAY)
 for x,w,c,t,num in [(35,274,BLUE,'Clinical inputs','1'),(355,339,BLUE,'Directional structure','2'),(742,434,TEAL,'Representation','3'),(1224,381,GOLD,'Uncertainty','4')]:
  s.box(x,107,w,485,'white',12,LINE,1.4)
  s.box(x,107,w,53,{'1':PALE,'2':PALE,'3':MINT,'4':SAND}[num],10)
  s.text(x+18,142,num,20,c,True);s.text(x+49,142,t,24,c,True)
 s.end();s.layer('Structured clinical variables')
 s.asset('clinical_record',54,187,96,112)
 for i,t in enumerate(['Demographic','Hemodynamic','Laboratory','Echocardiographic']):s.text(162,203+i*27,t,16.5,GRAY)
 # Input data matrix: feature families, no numerical patient records.
 for rr in range(6):
  for cc in range(9):s.box(64+cc*23,328+rr*23,18,18,['#D6E5ED','#8AB2C5','#ABCFC7','#D8C3A0'][(cc//2+rr%2)%4],2)
 s.text(169,499,'Patient × variable matrix',21,D,False,'middle')
 s.text(169,556,'Impute · encode · scale',22,BLUE,False,'middle')
 s.line(315,350,348,350,arrow=True)
 s.end();s.layer('Physiological graph and adjacency')
 s.asset('directed_graph',444,182,158,155)
 s.text(524,366,'Physiological prior A₀',22,BLUE,True,'middle')
 entries=[(0,1),(0,2),(1,3),(2,3),(3,4),(4,5)]
 matrix(s,378,404,6,20,entries);matrix(s,551,404,6,20,entries,weighted=True)
 s.line(505,464,542,464,arrow=True)
 s.text(437,558,'A₀',25,BLUE,True,'middle');s.text(610,558,'A',25,TEAL,True,'middle')
 s.text(524,635,'Gumbel–sigmoid gates',24,BLUE,True,'middle')
 s.line(700,350,735,350,arrow=True)
 s.end();s.layer('Encoder')
 layer_net(s,790,220,255,174,drop=[(1,1)])
 s.text(920,469,'GELU · dropout 0.20',21,GRAY,False,'middle')
 s.line(1058,307,1093,307,arrow=True);vector(s,1106,227,9,True)
 s.text(1113,424,'zᵢ',25,TEAL,True,'middle')
 s.text(959,548,'z'+sub('i')+' = f'+sub('θ')+'(x'+sub('i')+'; A)',29,TEAL,raw=True,serif=True,anchor='middle')
 s.line(959,602,959,655,arrow=True,dash=True)
 s.end();s.layer('Prototypes in latent space')
 s.box(742,670,434,259,MINT,12)
 s.text(765,709,'Prototype alignment',25,TEAL,True)
 clusters(s,765,729,390,130)
 s.text(1150,920,'Cosine similarity · τ = 0.20',20,GRAY,False,'end')
 s.end();s.layer('MC passes and predictive summaries')
 # Symbolic stochastic outputs; no model-performance estimates are invented.
 for r in range(3):
  s.text(1267,218+r*76,['1','2','30'][r],20,GRAY,False,'middle')
  for j in range(7):s.box(1293+j*30,197+r*76,21,27,'white' if (j+r)%4==0 else '#D0B890',3,LINE,.8)
 s.text(1414,430,'T = 30 stochastic passes',22,GOLD,True,'middle')
 s.text(1414,468,'Encoder dropout retained',21,GRAY,False,'middle')
 s.line(1184,350,1217,350,arrow=True)
 s.path('M1414,107 V80 H1020 V105',arrow=True,dash=True)
 s.line(1414,603,1414,653,arrow=True)
 s.box(1224,670,381,112,PALE,12)
 s.text(1246,707,'Mean probability',24,BLUE,True)
 for k,(lab,c) in enumerate(zip(['Normal','Mild','Severe'],COLORS)):
  s.box(1246+k*113,731,100,29,[PALE,MINT,SAND][k],4,c,1);s.text(1296+k*113,752,lab,18,c,False,'middle')
 s.box(1224,805,381,124,SAND,12)
 s.text(1246,844,'Variance + entropy',24,GOLD,True);s.text(1246,888,'Selective specialist review',22,D)
 s.end();s.layer('Regularization and data protocol')
 s.box(355,670,339,259,PALE,12)
 s.text(378,709,'Structural regularization',23,BLUE,True)
 for yy,lab,term in [(761,'Prior','‖A − A₀‖₁'),(812,'Sparse','‖A‖₁'),(863,'Acyclic','h(A)')]:
  s.circle(385,yy-6,5,BLUE);s.text(402,yy,lab,21,GRAY);s.text(671,yy,term,24,D,False,'end')
 s.text(60,720,'TRAIN / VALIDATION / TEST',17,GRAY,True)
 ring(s,168,826,66,[82,18,18],COLORS,17);s.text(168,836,'118',35,D,True,'middle')
 s.text(168,941,'82 / 18 / 18',23,BLUE,True,'middle')
 s.end();s.layer('Joint objective')
 s.line(35,982,1605,982,color=LINE)
 s.text(35,1032,'Joint objective',24,BLUE,True)
 s.text(262,1037,'L = L'+sub('CE')+' + αL'+sub('graph')+' + βL'+sub('proto')+' + γL'+sub('cal')+' + λ‖θ‖'+sub('2')+sup('2'),32,raw=True,serif=True)
 s.text(1604,1031,'Schematics',18,GRAY,False,'end')
 s.end();s.save('fig2_cardinal_framework')

def fig3():
 s=S(1600,1040,'Clinical prior, edge gates and regularization')
 s.layer('Clinical prior network')
 heading(s,35,49,'a','Clinical prior: 12 directed relations')
 # Background bands encode variable families without adding prose.
 s.box(36,113,183,590,PALE,10);s.box(254,113,592,178,MINT,10);s.box(254,337,592,366,'#F5F7F8',10)
 s.text(127,91,'Risk factors',21,BLUE,True,'middle');s.text(550,91,'Remodeling',21,TEAL,True,'middle');s.text(550,327,'Functional / biomarker variables',21,GRAY,True,'middle')
 # All twelve edges are exact source-target relations, not measured learned edges.
 s.path('M185,177 L270,205',arrow=True);s.path('M185,316 L270,236',arrow=True)
 s.line(430,223,476,223,arrow=True);s.line(629,223,683,223,arrow=True)
 s.line(750,168,750,196,arrow=True)
 s.path('M121,204 H22 V427 H288',arrow=True)
 s.line(442,427,485,427,arrow=True);s.path('M431,554 H463 V445 H485',arrow=True)
 s.line(618,427,682,427,arrow=True);s.line(750,250,750,400,arrow=True)
 s.path('M632,648 H657 V450 H682',arrow=True);s.line(750,621,750,454,arrow=True)
 nodes=[(121,177,128,'Age',BLUE),(121,316,128,'BMI',BLUE),(350,223,160,'Hypertension',TEAL),(552,223,154,'LV mass index',TEAL),(750,223,136,'LAVI',TEAL),(750,141,175,'Atrial fibrillation',TEAL),(365,427,154,'Average e′',BLUE),(365,554,132,'E wave',BLUE),(552,427,134,'E/e′',BLUE),(750,427,138,'Severity',GOLD),(552,648,160,'TR velocity',BLUE),(750,648,155,'NT-proBNP',BLUE)]
 for x,y,w,t,c in nodes:
  s.box(x-w/2,y-27,w,54,'white',8,c,1.6);s.text(x,y+7,t,20,c,t=='Severity','middle')
 s.text(36,754,'Reference-index edges encode concordance, not intervention effects.',21,GRAY)
 s.end();s.layer('Adjacency and gate learning')
 s.line(892,91,892,762,color=LINE)
 heading(s,935,49,'b','Learnable adjacency')
 matrix(s,943,144,12,20,PRIOR)
 s.text(1063,121,'Prior A₀',24,BLUE,True,'middle')
 s.text(1063,415,'12 × 12',20,GRAY,False,'middle')
 # A sigmoid is a mathematical illustration of the gating function.
 s.text(1390,121,'Gumbel–sigmoid',24,TEAL,True,'middle')
 s.line(1265,346,1534,346,color=LINE);s.line(1265,346,1265,163,color=LINE)
 pts=[(1268+i*5.1,339-170/(1+math.exp(-(i-25)/5))) for i in range(51)]
 s.path('M'+' L'.join(f'{x:.2f},{y:.2f}' for x,y in pts),TEAL,3)
 s.text(1275,163,'1',18,GRAY);s.text(1275,337,'0',18,GRAY);s.text(1390,388,'Differentiable edge gates',20,GRAY,False,'middle')
 s.line(1195,264,1244,264,arrow=True)
 s.path('M1400,417 V461 H1064 V492',arrow=True)
 matrix(s,943,510,12,20,PRIOR,c=TEAL,weighted=True)
 s.text(1235,538,'A (schematic)',24,TEAL,True)
 s.asset('directed_graph',1270,565,161,149,TEAL)
 s.text(1390,748,'Refined structure · schematic',19,GRAY,False,'middle')
 s.end();s.layer('Regularization terms')
 s.line(35,808,1565,808,color=LINE)
 for x,c,title,formula in [(35,BLUE,'Prior alignment','0.25‖A − A₀‖₁'),(554,TEAL,'Sparsity','η'+sub('s')+'‖A‖₁'),(1073,GOLD,'Acyclicity','0.10h(A)')]:
  s.box(x,849,492,145,{'Prior alignment':PALE,'Sparsity':MINT,'Acyclicity':SAND}[title],10)
  if title=='Prior alignment':
   matrix(s,x+22,888,4,17,[(0,1),(1,2),(2,3)],c=c);matrix(s,x+73,919,3,14,[(0,1),(1,2)],c=c)
  elif title=='Sparsity':matrix(s,x+24,885,5,17,[(0,1),(1,3),(3,4)],c=c)
  else:
   for a,b in [((x+33,931),(x+72,883)),((x+72,883),(x+116,932)),((x+33,940),(x+115,940))]:s.line(*a,*b,color=c,arrow=True)
   for X,Y in [(x+30,942),(x+72,879),(x+121,942)]:s.circle(X,Y,8,'white',c,2)
  s.text(x+150,891,title,23,c,True);s.text(x+150,950,formula,29,D,raw=True,serif=True)
 s.end();s.save('fig3_directional_graph_learning')

def fig4():
 s=S(1600,1100,'Stochastic encoder passes and uncertainty-guided review')
 s.layer('Stochastic forward passes')
 heading(s,35,49,'a','Stochastic forward passes')
 s.asset('clinical_record',47,166,106,130)
 vector(s,165,184,7,True,BLUE);s.text(130,354,'Patient xᵢ',25,BLUE,True,'middle')
 s.path('M194,238 H241 V157 H288',arrow=True);s.path('M241,238 V303 H288',arrow=True);s.path('M241,303 V449 H288',arrow=True)
 for row,(yy,drop) in enumerate([(98,[(1,1),(1,3)]),(244,[(0,2),(2,1)]),(390,[(1,0),(2,2)])]):
  s.box(300,yy,413,126,PALE,8)
  s.text(322,yy+29,['t = 1','t = 2','t = 30'][row],20,BLUE,True)
  layer_net(s,398,yy+12,175,84,drop,False)
  vector(s,623,yy+25,4,True,TEAL)
  s.line(722,yy+63,780,yy+63,arrow=True)
 s.text(300,560,'Same encoder · resampled masks',23,BLUE,True)
 s.text(300,596,'T = 30     dropout = 0.20',24,GRAY)
 s.end();s.layer('Probability vectors')
 s.box(789,98,251,418,MINT,10)
 s.text(915,135,'Classifier',25,TEAL,True,'middle')
 for yy in [195,301,407]:
  for k,c in enumerate(COLORS):s.circle(848+k*65,yy,11,c)
  s.line(832,yy-30,987,yy-30,color=LINE)
 s.text(915,489,'Softmax',23,TEAL,False,'middle')
 s.line(1053,302,1105,302,arrow=True)
 s.text(1299,133,'Stochastic probabilities',25,D,True,'middle')
 for k,(lab,c) in enumerate(zip(['Normal','Mild','Severe'],COLORS)):s.text(1197+k*127,183,lab,20,c,True,'middle')
 for row,y in enumerate([218,321,424]):
  s.text(1104,y+34,['1','2','30'][row],22,GRAY,False,'middle')
  for k in range(3):
   s.box(1146+k*127,y,102,67,[PALE,MINT,SAND][k],7)
   s.text(1197+k*127,y+42,'p'+sub('i'+str(k+1))+sup('('+['1','2','30'][row]+')'),26,COLORS[k],False,'middle',raw=True,serif=True)
 s.text(1527,557,'Passes 3–29 omitted',20,GRAY,False,'end')
 s.end();s.layer('Predictive mean and uncertainty')
 heading(s,35,678,'b','Prediction and selective review')
 s.path('M1299,583 V618 H650 V704',arrow=True);s.path('M1071,618 V704',arrow=True)
 s.box(35,716,734,319,PALE,12);s.box(810,716,755,319,MINT,12)
 s.text(61,759,'Mean → class',26,BLUE,True)
 s.text(61,811,'p̄'+sub('ik')+' = (1/T) ∑'+sub('t=1')+sup('T')+' p'+sub('ik')+sup('(t)'),30,raw=True,serif=True)
 # A symbolic three-class output: variables, not invented measurements.
 for k,c in enumerate(COLORS):
  x=76+k*204;s.box(x,861,174,63,'white',7,c,1.2)
  s.text(x+87,901,'p̄'+sub('i'+str(k+1)),29,c,False,'middle',raw=True,serif=True)
 s.text(399,983,'ŷ'+sub('i')+' = arg max'+sub('k')+' p̄'+sub('ik'),29,BLUE,False,'middle',raw=True,serif=True)
 s.text(835,759,'Variance + entropy',26,TEAL,True)
 s.text(835,807,'v'+sub('ik')+' = (1/T) ∑'+sub('t=1')+sup('T')+' (p'+sub('ik')+sup('(t)')+' − p̄'+sub('ik')+')²',28,raw=True,serif=True)
 # Compact distribution illustration: horizontal dispersion encodes uncertainty.
 s.text(849,856,'Lower',20,BLUE);s.text(849,922,'Higher',20,GOLD)
 for row,c in enumerate([BLUE,GOLD]):
  cy=850+row*66;s.line(962,cy,1243,cy,color=LINE)
  for k in range(18):
   dx=((k*17)%37-18)*(1.15 if row==0 else 6.1)
   s.circle(1100+dx,cy+((k*11)%15-7),3.3,c)
 s.text(1100,962,'Dispersion schematic',17,GRAY,False,'middle')
 s.line(1263,850,1302,850,arrow=True);s.line(1263,916,1302,916,arrow=True)
 s.box(1312,825,228,55,PALE,7);s.text(1426,860,'Routine review',21,BLUE,True,'middle')
 s.box(1312,891,228,55,SAND,7);s.text(1426,925,'Specialist review',20,GOLD,True,'middle')
 s.text(836,1003,'Clinical decisions remain with the clinician.',21,GRAY)
 s.end();s.save('fig4_uncertainty_prediction')

for fn in [fig1,fig2,fig3,fig4]:fn()
print('Four richer scientific figures created using simple editable materials.')
